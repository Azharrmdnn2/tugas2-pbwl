<h3>Logout</h3>

<form action="login_proses.php" method="POST">
  <input type="submit" name="b_logout" value="Logout">
</form>