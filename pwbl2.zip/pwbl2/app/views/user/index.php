<h2>User</h2>

<a href="<?php echo URL; ?>/user/input" class="btn">Input User</a>

<table>
  <tr>
    <th>Id</th>
    <th>METERAN</th>
    <th>Nama</th>
    <th>Alamat</th>
    <th>Telp</th>
    <th>Kode Pos</th>
    <th>Edit</th>
    <th>Delete</th>
  </tr>

  <?php foreach ($data['rows'] as $row) { ?>
    <tr>
      <td><?php echo $row['user_id']; ?></td>
      <td><?php echo $row['pel_meteran']; ?></td>
      <td><?php echo $row['user_nama']; ?></td>
      <td><?php echo $row['user_alamat']; ?></td>
      <td><?php echo $row['user_hp']; ?></td>
      <td><?php echo $row['user_pos']; ?></td>
      <td><a href="<?php echo URL; ?>/user/edit/<?php echo $row['user_id']; ?>" class="btn">Edit</a></td>
      <td><a href="<?php echo URL; ?>/user/delete/<?php echo $row['user_id']; ?>" class="btn">Delete</a></td>
    </tr>
  <?php } ?>
</table>