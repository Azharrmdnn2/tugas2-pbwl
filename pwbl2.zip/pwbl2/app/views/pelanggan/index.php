<h2>Pelanggan</h2>

<a href="<?php echo URL; ?>/pelanggan/input" class="btn">Input Pelanggan</a>

<table>
  <tr>
    <th>Id</th>
    <th>Pel_No</th>
    <th>Nama</th>
    <th>Alamat</th>
    <th>Hp</th>
    <th>Ktp</th>
    <th>Seri</th>
    <th>Meteran</th>
    <th>Edit</th>
    <th>Delete</th>
  </tr>

  <?php foreach ($data['rows'] as $row) { ?>
    <tr>
      <td><?php echo $row['pel_id']; ?></td>
      <td><?php echo $row['pel_no']; ?></td>
      <td><?php echo $row['pel_nama']; ?></td>
      <td><?php echo $row['pel_alamat']; ?></td>
      <td><?php echo $row['pel_hp']; ?></td>
      <td><?php echo $row['pel_ktp']; ?></td>
      <td><?php echo $row['pel_seri']; ?></td>
      <td><?php echo $row['pel_meteran']; ?></td>
      <td><a href="<?php echo URL; ?>/pelanggan/edit/<?php echo $row['pel_id']; ?>" class="btn">Edit</a></td>
      <td><a href="<?php echo URL; ?>/pelanggan/delete/<?php echo $row['pel_id']; ?>" class="btn">Delete</a></td>
    </tr>
  <?php } ?>
</table>