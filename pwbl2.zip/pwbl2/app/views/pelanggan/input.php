<h2>Input Pelanggan</h2>

<form action="<?php echo URL; ?>/pelanggan/simpan" method="post">
  <table>
    <tr>
      <td>ID GOLLLL</td>
      <td><input type="text" name="pel_id_gol"></td>
    </tr>
    <tr>
      <td>ID USERSSSS</td>
      <td><input type="text" name="pel_id_user"></td>
    </tr>
    <tr>
      <td>No Pelanggan</td>
      <td><input type="text" name="pel_no"></td>
    </tr>
    <tr>
      <td>Nama</td>
      <td><input type="text" name="pel_nama"></td>
    </tr>
    <tr>
      <td>Alamat</td>
      <td><textarea name="pel_alamat" id="" cols="30" rows="10"></textarea></td>
    </tr>
    <tr>
      <td>Hp</td>
      <td><input type="text" name="pel_hp"></td>
    </tr>
    <tr>
      <td>Ktp</td>
      <td><input type="text" name="pel_ktp"></td>
    </tr>
    <tr>
      <td>Seri</td>
      <td><input type="text" name="pel_seri"></td>
    </tr>
    <tr>
      <td>Meteran</td>
      <td><input type="text" name="pel_meteran"></td>
    </tr>
    <tr>
      <td></td>
      <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
    </tr>
  </table>
</form>