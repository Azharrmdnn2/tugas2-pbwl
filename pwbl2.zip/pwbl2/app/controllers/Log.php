<?php

namespace App\Controllers;

use App\Core\Controller;

class Log extends Controller
{

    public object $model;

    public function __construct()
    {

        $this->model = new \App\Models\Log_model();
    }

    public function index()
    {
        $data['title'] = 'Login';
        $this->dashboard('login/index', $data);
    }
    public function login()
    {
        $user_email = $_POST['user_email'];
        $user_password = $_POST['user_password'];
        //        echo $user_email .'<br>'. $user_password;

        $data['login'] = $this->model->getUser($user_email, $user_password);
        //        var_dump($data['login']);

        session_start();
        if ($data['login'] == NULL) {
            header("location:" . URL . "/404");
        } else {
            foreach ($data['login'] as $row) :
                $_SESSION['admin_name'] = $row['admin_name'];
                header("location:" . URL . '/dashboard');
            endforeach;
        }
    }
    public function logout()
    {
        session_start();
        session_destroy();
        header('location:' . URL . '');
    }
}
